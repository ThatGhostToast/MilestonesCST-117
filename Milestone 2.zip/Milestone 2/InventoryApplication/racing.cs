﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Version 2.0

    //Child Class
    public class Racing : addGame
    {
        //Getters and Setters
        public int totalCars { get; private set; }

        //Racing Constructor
        public Racing(string gameName, string date, string graphicsQual, string gameGenre, double replayScore, double campLength, int carTotal): base (gameName, date, graphicsQual,
            gameGenre, replayScore, campLength)
        {
            //Extra data specifically for this class
            totalCars = carTotal;
        }

    }
}
