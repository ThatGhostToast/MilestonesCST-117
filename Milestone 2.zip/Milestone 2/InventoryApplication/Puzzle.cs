﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Verison 2.0

    //Child Class
    public class Puzzle : addGame
    {
        //Getters and setters
        public int totalPuzzles { get; private set; }
        public string difficulty { get; private set; }

        //Puzzle constructor
        public Puzzle(string gameName, string date, string graphicsQual, string gameGenre, double replayScore, double campLength, int puzzleTotal, string gameDifficulty) : base(gameName, date,
            graphicsQual, gameGenre, replayScore, campLength)
        {
            //Extra data specifically for this class
            totalPuzzles = puzzleTotal;
            difficulty = gameDifficulty;

        }


    }
}
