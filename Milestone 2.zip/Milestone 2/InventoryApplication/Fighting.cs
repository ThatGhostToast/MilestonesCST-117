﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Version 2.0

    //Child Class
    public class Fighting : addGame
    {
        //Getters and setters
        public int totalFighters { get; private set; }
        public int maximumFighters { get; private set; }

        //Fighting constructor 
        public Fighting(string gameName, string date, string graphicsQual, string gameGenre, double replayScore, double campLength, int fighterTotal, int maxFighters): base (gameName, date, graphicsQual,
            gameGenre, replayScore, campLength)
        {
            //Extra data specifically for this class
            totalFighters = fighterTotal;
            maximumFighters = maxFighters;


        }
    }
}
