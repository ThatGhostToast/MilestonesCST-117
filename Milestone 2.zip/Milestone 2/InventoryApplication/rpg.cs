﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Version 2.0

    //Child class
    public class RPG : addGame
    {
        //Getters and setters
        public double worldSize { get; private set; }
        public int totalQuests { get; private set; }
        public string plotSummary { get; private set; }

        //RPG constructor
        public RPG (string gameName, string date, string graphicsQual, string gameGenre, double replayScore, double campLength, double wSize, int questTotal, string plot): base (gameName, date,
            graphicsQual, gameGenre, replayScore, campLength)
        {
            //Extra data specifically for this class
            worldSize = wSize;
            totalQuests = questTotal;
            plotSummary = plot;

        }


    }
}
