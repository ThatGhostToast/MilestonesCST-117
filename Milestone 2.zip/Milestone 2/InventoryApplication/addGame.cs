﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Version 2.0

    //Parent class
    public class addGame
    {
        private string gameName;
        private string date;
        private string graphicsQual;
        private double replayScore;
        private double campLength;
        private int weaponTypes;

        //Declare getters and setters
        public string name { get; private set; }
        public string releaseDate { get; private set; }
        public string graphics { get; private set; }
        public string genre { get; private set; }
        public double replayability { get; private set; }
        public double campaignLength { get; private set; }

        //Create the addGame constructor
        public addGame(string gameName, string date, string graphicsQual, string gameGenre, double replayScore, double campLength)
        {
            //Setting the property values
            name = gameName;
            releaseDate = date;
            graphics = graphicsQual;
            genre = gameGenre;
            replayability = replayScore;
            campaignLength = campLength;
        }

        public Boolean addToInv()
        {

            return true;
        }

    }
}
