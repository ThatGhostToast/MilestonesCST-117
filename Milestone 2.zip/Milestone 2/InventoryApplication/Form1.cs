﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryApplication
{
    public partial class gameInventory : Form
    {
        public gameInventory()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Zac Almas
        /// CST-117
        /// Inventory Class Project
        /// Version 2.0
        /// 
        /// Clicking this button adds a new game into the database
        /// [Work in progress build, so far it does not save the database but it 
        ///  does add the games into a data grid and takes in all the game information]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddGame_Click(object sender, EventArgs e)
        {
            //Taking in the variables from the form
            string gameName = txtGameName.Text.ToString();
            string releaseDate = txtReleaseDate.Text.ToString();
            int gameGenre = lbGameGenre.SelectedIndex;
            string genreString = "";
            string graphicsQuality = txtGraphicsQuality.Text.ToString();
            double campaignLength = 0;
            double replayabilityScore = 0;

            //------------------------------------------------------------------
            //Try catch to make sure the user entered an int for the length of the campaign in hours
            try
            {
                campaignLength = double.Parse(txtCampaignLength.Text);
            }
            catch (FormatException)
            {
                //Shows the user where the error is
                txtCampaignLength.Focus();
                txtCampaignLength.SelectAll();
            }

            //Try catch to make sure the user entered a number for the replayability score
            try
            {
                replayabilityScore = double.Parse(txtReplayabilityScore.Text);;
            }
            catch (FormatException)
            {
                //Shows the user where the error is
                txtReplayabilityScore.Focus();
                txtReplayabilityScore.SelectAll();
            }

            //------------------------------------------------------------------
            //If statements that tell the program where the data goes
            //Certain aspects are still a work in progress: world size, total weapons, situation, etc but I'm activly working on implementing a way for user input that looks good.
            //If FPS is selected:
            if (gameGenre == 0)
            {
                //Input variables
                genreString = "FPS";
                int weaponTotal = 80;
                int gameTypes = 5;

                //Sending the data to the FPS class
                FPS newGame = new FPS(gameName, releaseDate, graphicsQuality, genreString, replayabilityScore, campaignLength, weaponTotal, gameTypes);

                //Putting the data into the data grid
                //Using this line of code for "index" allows the user to keep adding in new games and it will create more rows in the data grid
                var index = this.dgvInventory.Rows.Add();
                this.dgvInventory.Rows[index].Cells[0].Value = newGame.name;
                this.dgvInventory.Rows[index].Cells[1].Value = newGame.genre;
                this.dgvInventory.Rows[index].Cells[2].Value = newGame.releaseDate;
                this.dgvInventory.Rows[index].Cells[3].Value = newGame.graphics;
                this.dgvInventory.Rows[index].Cells[4].Value = newGame.campaignLength;
                this.dgvInventory.Rows[index].Cells[5].Value = newGame.replayability;
                this.dgvInventory.Rows[index].Cells[6].Value = "Total weapons: " + newGame.totalWeaponTypes;
                this.dgvInventory.Rows[index].Cells[7].Value = "Total game modes: " + newGame.gameType;


            }
            //---------------------
            //If RPG is selected:
            if (gameGenre == 1)
            {
                //Input variables
                genreString = "RPG";
                double worldSize = 6000;
                int totalQuests = 500;
                string plotSummary = "Kill the dragon.";

                //Sending the data to the RPG class
                RPG newGame = new RPG(gameName, releaseDate, graphicsQuality, genreString, replayabilityScore, campaignLength, worldSize, totalQuests, plotSummary);

                //Putting the data into the data grid
                var index = this.dgvInventory.Rows.Add();
                this.dgvInventory.Rows[index].Cells[0].Value = newGame.name;
                this.dgvInventory.Rows[index].Cells[1].Value = newGame.genre;
                this.dgvInventory.Rows[index].Cells[2].Value = newGame.releaseDate;
                this.dgvInventory.Rows[index].Cells[3].Value = newGame.graphics;
                this.dgvInventory.Rows[index].Cells[4].Value = newGame.campaignLength;
                this.dgvInventory.Rows[index].Cells[5].Value = newGame.replayability;
                this.dgvInventory.Rows[index].Cells[6].Value = "World size: " + newGame.worldSize;
                this.dgvInventory.Rows[index].Cells[7].Value = "Total quests: " + newGame.totalQuests;
                this.dgvInventory.Rows[index].Cells[8].Value = "Plot Summary: " + newGame.plotSummary;

            }
            //---------------------
            //If Racing is selected:
            if (gameGenre == 2)
            {
                //Input variables
                genreString = "Racing";
                int totalCars = 150;

                //Sending data to the Racing class
                Racing newGame = new Racing(gameName, releaseDate, graphicsQuality, genreString, replayabilityScore, campaignLength, totalCars);

                //Putting data into the data grid
                var index = this.dgvInventory.Rows.Add();
                this.dgvInventory.Rows[index].Cells[0].Value = newGame.name;
                this.dgvInventory.Rows[index].Cells[1].Value = newGame.genre;
                this.dgvInventory.Rows[index].Cells[2].Value = newGame.releaseDate;
                this.dgvInventory.Rows[index].Cells[3].Value = newGame.graphics;
                this.dgvInventory.Rows[index].Cells[4].Value = newGame.campaignLength;
                this.dgvInventory.Rows[index].Cells[5].Value = newGame.replayability;
                this.dgvInventory.Rows[index].Cells[6].Value = "Total Cars: " + newGame.totalCars;

            }
            //---------------------
            //If Survival is selected:
            if (gameGenre == 3)
            {
                //Input variables
                genreString = "Survival";
                string survivalSituation = "Survive the wild.";

                //Sending data to the Survival class
                Survival newGame = new Survival(gameName, releaseDate, graphicsQuality, genreString, replayabilityScore, campaignLength, survivalSituation);

                //Putting data into the data grid
                var index = this.dgvInventory.Rows.Add();
                this.dgvInventory.Rows[index].Cells[0].Value = newGame.name;
                this.dgvInventory.Rows[index].Cells[1].Value = newGame.genre;
                this.dgvInventory.Rows[index].Cells[2].Value = newGame.releaseDate;
                this.dgvInventory.Rows[index].Cells[3].Value = newGame.graphics;
                this.dgvInventory.Rows[index].Cells[4].Value = newGame.campaignLength;
                this.dgvInventory.Rows[index].Cells[5].Value = newGame.replayability;
                this.dgvInventory.Rows[index].Cells[6].Value = "Situation: " + newGame.survivalSituation;

            }
            //---------------------
            //If Fighting is selected:
            if (gameGenre == 4)
            {
                //Input variables
                genreString = "Fighting";
                int totalFighters = 20;
                int maximumFighters = 2;

                //Sending the data to the Fighting class
                Fighting newGame = new Fighting(gameName, releaseDate, graphicsQuality, genreString, replayabilityScore, campaignLength, totalFighters, maximumFighters);

                //Putting data into the data grid
                var index = this.dgvInventory.Rows.Add();
                this.dgvInventory.Rows[index].Cells[0].Value = newGame.name;
                this.dgvInventory.Rows[index].Cells[1].Value = newGame.genre;
                this.dgvInventory.Rows[index].Cells[2].Value = newGame.releaseDate;
                this.dgvInventory.Rows[index].Cells[3].Value = newGame.graphics;
                this.dgvInventory.Rows[index].Cells[4].Value = newGame.campaignLength;
                this.dgvInventory.Rows[index].Cells[5].Value = newGame.replayability;
                this.dgvInventory.Rows[index].Cells[6].Value = "Total fighters: " + newGame.totalFighters;
                this.dgvInventory.Rows[index].Cells[7].Value = "Max fighters: " + newGame.maximumFighters;

            }
            //---------------------
            //If Puzzle is selected:
            if (gameGenre == 5)
            {
                //Input variables
                genreString = "Puzzle";
                int totalPuzzles = 500;
                string difficulty = "Medium";

                //Sending the data to the Puzzle class
                Puzzle newGame = new Puzzle(gameName, releaseDate, graphicsQuality, genreString, replayabilityScore, campaignLength, totalPuzzles, difficulty);

                //Putting the data into the data grid
                var index = this.dgvInventory.Rows.Add();
                this.dgvInventory.Rows[index].Cells[0].Value = newGame.name;
                this.dgvInventory.Rows[index].Cells[1].Value = newGame.genre;
                this.dgvInventory.Rows[index].Cells[2].Value = newGame.releaseDate;
                this.dgvInventory.Rows[index].Cells[3].Value = newGame.graphics;
                this.dgvInventory.Rows[index].Cells[4].Value = newGame.campaignLength;
                this.dgvInventory.Rows[index].Cells[5].Value = newGame.replayability;
                this.dgvInventory.Rows[index].Cells[6].Value = "Total puzzles: " + newGame.totalPuzzles;
                this.dgvInventory.Rows[index].Cells[7].Value = "Difficulty: " + newGame.difficulty;

            }


        }

        /// <summary>
        /// Clicking this button closes the program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
