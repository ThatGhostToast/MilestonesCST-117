﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Version 2.0

    //Child Class
    public class Survival : addGame
    {
        //Getters and setters
        public string survivalSituation { get; private set; }

        //Survival Constructor
        public Survival(string gameName, string date, string graphicsQual, string gameGenre, double replayScore, double campLength, string situation): base (gameName,
            date, graphicsQual, gameGenre, replayScore, campLength)
        {
            //Extra data specifically for this class
            survivalSituation = situation;
        }

        /// <summary>
        /// This checks if the game entered is a horror survival
        /// [Work in progress: does not return anything yet]
        /// </summary>
        /// <returns></returns>
        public Boolean horrorChecker()
        {
            return true;
        }


    }
}
