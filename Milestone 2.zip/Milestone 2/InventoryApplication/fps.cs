﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApplication
{
    //Zac Almas
    //CST-117
    //Inventory Class Project
    //Version 2.0

    //Child Class
    public class FPS : addGame
    {
        //Getters and setters
        public int totalWeaponTypes { get; private set; }
        public int gameType { get; private set; }

        /// <summary>
        /// The FPS constructor
        /// </summary>
        /// <param name="gameName"></param>
        /// <param name="date"></param>
        /// <param name="graphicsQual"></param>
        /// <param name="replayScore"></param>
        /// <param name="campLength"></param>
        public FPS(string gameName, string date, string graphicsQual, string genre, double replayScore, double campLength, int weaponTotal, int types): base(gameName,
            date, graphicsQual, genre, replayScore, campLength)
        {
            //Extra data specifically for this class
            totalWeaponTypes = weaponTotal;
            gameType = types;
        }


    }
}
