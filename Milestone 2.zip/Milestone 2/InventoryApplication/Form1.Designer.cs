﻿namespace InventoryApplication
{
    partial class gameInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(gameInventory));
            this.btnAddGame = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbGameGenre = new System.Windows.Forms.ListBox();
            this.txtGameName = new System.Windows.Forms.TextBox();
            this.txtReleaseDate = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtGraphicsQuality = new System.Windows.Forms.TextBox();
            this.txtCampaignLength = new System.Windows.Forms.TextBox();
            this.txtReplayabilityScore = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            this.gameNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameGenreColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.releaseDateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.graphicsQualityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.campaignLengthColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.replayColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.other = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.other1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.other2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddGame
            // 
            this.btnAddGame.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddGame.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGame.Location = new System.Drawing.Point(88, 413);
            this.btnAddGame.Name = "btnAddGame";
            this.btnAddGame.Size = new System.Drawing.Size(167, 61);
            this.btnAddGame.TabIndex = 0;
            this.btnAddGame.Text = "Add Game";
            this.btnAddGame.UseVisualStyleBackColor = false;
            this.btnAddGame.Click += new System.EventHandler(this.btnAddGame_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClose.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(1518, 456);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(123, 78);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Exit";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(183, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Please select a genre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Please enter the";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "title of the game";
            // 
            // lbGameGenre
            // 
            this.lbGameGenre.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGameGenre.FormattingEnabled = true;
            this.lbGameGenre.ItemHeight = 16;
            this.lbGameGenre.Items.AddRange(new object[] {
            "First Person Shooter (FPS)",
            "Role Playing Game (RPG)",
            "Racing",
            "Survival",
            "Fighting",
            "Puzzle"});
            this.lbGameGenre.Location = new System.Drawing.Point(176, 87);
            this.lbGameGenre.Name = "lbGameGenre";
            this.lbGameGenre.Size = new System.Drawing.Size(184, 116);
            this.lbGameGenre.TabIndex = 5;
            // 
            // txtGameName
            // 
            this.txtGameName.Location = new System.Drawing.Point(28, 116);
            this.txtGameName.Name = "txtGameName";
            this.txtGameName.Size = new System.Drawing.Size(100, 22);
            this.txtGameName.TabIndex = 6;
            // 
            // txtReleaseDate
            // 
            this.txtReleaseDate.Location = new System.Drawing.Point(28, 199);
            this.txtReleaseDate.Name = "txtReleaseDate";
            this.txtReleaseDate.Size = new System.Drawing.Size(100, 22);
            this.txtReleaseDate.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Please enter the";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 18);
            this.label5.TabIndex = 10;
            this.label5.Text = "Release date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(183, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 18);
            this.label6.TabIndex = 11;
            this.label6.Text = "Length of the campaign";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 18);
            this.label7.TabIndex = 12;
            this.label7.Text = "Graphics Capabilites";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(231, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 18);
            this.label8.TabIndex = 13;
            this.label8.Text = "in hours ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(16, 234);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 18);
            this.label11.TabIndex = 16;
            this.label11.Text = "Please enter the";
            // 
            // txtGraphicsQuality
            // 
            this.txtGraphicsQuality.Location = new System.Drawing.Point(28, 271);
            this.txtGraphicsQuality.Name = "txtGraphicsQuality";
            this.txtGraphicsQuality.Size = new System.Drawing.Size(100, 22);
            this.txtGraphicsQuality.TabIndex = 17;
            // 
            // txtCampaignLength
            // 
            this.txtCampaignLength.Location = new System.Drawing.Point(215, 269);
            this.txtCampaignLength.Name = "txtCampaignLength";
            this.txtCampaignLength.Size = new System.Drawing.Size(100, 22);
            this.txtCampaignLength.TabIndex = 18;
            // 
            // txtReplayabilityScore
            // 
            this.txtReplayabilityScore.Location = new System.Drawing.Point(116, 365);
            this.txtReplayabilityScore.Name = "txtReplayabilityScore";
            this.txtReplayabilityScore.Size = new System.Drawing.Size(100, 22);
            this.txtReplayabilityScore.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(205, 214);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 18);
            this.label9.TabIndex = 20;
            this.label9.Text = "Please enter the";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(82, 310);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(173, 18);
            this.label10.TabIndex = 21;
            this.label10.Text = "Please enter on a scale";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(82, 328);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(182, 18);
            this.label12.TabIndex = 22;
            this.label12.Text = "of 1 to 10 how replayable";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(122, 345);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 18);
            this.label13.TabIndex = 23;
            this.label13.Text = "is the game";
            // 
            // dgvInventory
            // 
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gameNameColumn,
            this.gameGenreColumn,
            this.releaseDateColumn,
            this.graphicsQualityColumn,
            this.campaignLengthColumn,
            this.replayColumn,
            this.other,
            this.other1,
            this.other2});
            this.dgvInventory.Location = new System.Drawing.Point(404, 13);
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.RowHeadersWidth = 51;
            this.dgvInventory.RowTemplate.Height = 24;
            this.dgvInventory.Size = new System.Drawing.Size(1237, 437);
            this.dgvInventory.TabIndex = 24;
            // 
            // gameNameColumn
            // 
            this.gameNameColumn.HeaderText = "Name";
            this.gameNameColumn.MinimumWidth = 6;
            this.gameNameColumn.Name = "gameNameColumn";
            this.gameNameColumn.Width = 125;
            // 
            // gameGenreColumn
            // 
            this.gameGenreColumn.HeaderText = "Genre";
            this.gameGenreColumn.MinimumWidth = 6;
            this.gameGenreColumn.Name = "gameGenreColumn";
            this.gameGenreColumn.Width = 125;
            // 
            // releaseDateColumn
            // 
            this.releaseDateColumn.HeaderText = "Release Date";
            this.releaseDateColumn.MinimumWidth = 6;
            this.releaseDateColumn.Name = "releaseDateColumn";
            this.releaseDateColumn.Width = 125;
            // 
            // graphicsQualityColumn
            // 
            this.graphicsQualityColumn.HeaderText = "Graphics Quality";
            this.graphicsQualityColumn.MinimumWidth = 6;
            this.graphicsQualityColumn.Name = "graphicsQualityColumn";
            this.graphicsQualityColumn.Width = 125;
            // 
            // campaignLengthColumn
            // 
            this.campaignLengthColumn.HeaderText = "Campaign Length";
            this.campaignLengthColumn.MinimumWidth = 6;
            this.campaignLengthColumn.Name = "campaignLengthColumn";
            this.campaignLengthColumn.Width = 125;
            // 
            // replayColumn
            // 
            this.replayColumn.HeaderText = "Replayability Score";
            this.replayColumn.MinimumWidth = 6;
            this.replayColumn.Name = "replayColumn";
            this.replayColumn.Width = 125;
            // 
            // other
            // 
            this.other.HeaderText = "Other Info:";
            this.other.MinimumWidth = 6;
            this.other.Name = "other";
            this.other.Width = 125;
            // 
            // other1
            // 
            this.other1.HeaderText = "";
            this.other1.MinimumWidth = 6;
            this.other1.Name = "other1";
            this.other1.Width = 125;
            // 
            // other2
            // 
            this.other2.HeaderText = "";
            this.other2.MinimumWidth = 6;
            this.other2.Name = "other2";
            this.other2.Width = 125;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(52, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(225, 33);
            this.label14.TabIndex = 25;
            this.label14.Text = "Add new game:";
            // 
            // gameInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(1687, 546);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dgvInventory);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtReplayabilityScore);
            this.Controls.Add(this.txtCampaignLength);
            this.Controls.Add(this.txtGraphicsQuality);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtReleaseDate);
            this.Controls.Add(this.txtGameName);
            this.Controls.Add(this.lbGameGenre);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAddGame);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "gameInventory";
            this.Text = "Game Inventory";
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddGame;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbGameGenre;
        private System.Windows.Forms.TextBox txtGameName;
        private System.Windows.Forms.TextBox txtReleaseDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtGraphicsQuality;
        private System.Windows.Forms.TextBox txtCampaignLength;
        private System.Windows.Forms.TextBox txtReplayabilityScore;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameGenreColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn releaseDateColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn graphicsQualityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn campaignLengthColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn replayColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn other;
        private System.Windows.Forms.DataGridViewTextBoxColumn other1;
        private System.Windows.Forms.DataGridViewTextBoxColumn other2;
        private System.Windows.Forms.Label label14;
    }
}

