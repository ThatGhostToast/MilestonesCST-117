﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.CompilerServices;

/// <summary>
/// Zac Almas
/// CST-117
/// 12/6/20
/// This is my code for milestone 3
/// </summary>
namespace BusinessLogic
{
    public class InventoryManager : InventoryParent
    {
        //Creating a reference variable for the inventory
        private List<InventoryGame> myInventory;

        /// <summary>
        /// Constructor for our inventory manager class
        /// </summary>
        /// <param name="gameNameVal"></param>
        /// <param name="releaseDateVal"></param>
        /// <param name="graphicsQualVal"></param>
        /// <param name="genreVal"></param>
        /// <param name="campaignLengthVal"></param>
        /// <param name="replayabilityVal"></param>
        /// <param name="gameInventoryVal"></param>
        public InventoryManager (string gameNameVal, string releaseDateVal, string graphicsQualVal, string genreVal, double campaignLengthVal, double replayabilityVal, int quantityVal, int idVal,
            List<InventoryGame> gameInventoryVal) : base(gameNameVal, releaseDateVal, graphicsQualVal, genreVal, campaignLengthVal, replayabilityVal, quantityVal, idVal)
        {
            myInventory = gameInventoryVal;
        }

        /// <summary>
        /// Method to add items into the inventory
        /// </summary>
        /// <returns></returns>
        public List<InventoryGame> addToInventory()
        {
            myInventory.Add(new InventoryGame(gameName, releaseDate, graphicsQual, genre, campaignLength, replayability, quantity, id));
            return (myInventory);
        }

        /// <summary>
        /// Method that removes a game from the inventory
        /// </summary>
        /// <param name="gameId"></param>
        /// <returns></returns>
        public List<InventoryGame> deleteFromInventory(int gameId)
        {
            var gameToRemove = myInventory.SingleOrDefault(r => r.id == gameId);
            if (gameToRemove != null)
            {
                myInventory.Remove(gameToRemove);
            }
            return myInventory;
        }

        /// <summary>
        /// This method allows the user to update the quantity of the games in the inventory
        /// </summary>
        /// <param name="newQuantity"></param>
        /// <param name="gameId"></param>
        /// <returns></returns>
        public List<InventoryGame> restockGame(int newQuantity, int gameId)
        {
            var gameToUpdate = myInventory.FirstOrDefault(d => d.id == gameId);
            if (gameToUpdate != null)
            {
                gameToUpdate.quantity = newQuantity;
            }
            
            
            return myInventory;
        }

        /// <summary>
        /// This method allows the user to search for an item in the table
        /// </summary>
        /// <param name="gameId"></param>
        /// <param name="gameName"></param>
        /// <returns></returns>
        public List<InventoryGame> searchInv(int gameId, string gameName)
        {
            List<InventoryGame> searchInventory = new List<InventoryGame>();

            //-----------------------------------------------------------------
            //Displaying the search results was assisted by Michael Duisenberg
            //-----------------------------------------------------------------
            List<InventoryGame> displaySearch = new List<InventoryGame>();

            //Loading my inventory into a parameter
            searchInventory = myInventory;

            if (searchInventory.Exists(game => game.id == gameId && game.gameName == gameName) == true)
            {
                displaySearch.Add(searchInventory.Find(game => game.id == gameId && game.gameName == gameName));
            }
            return displaySearch;
        }



    }
}
