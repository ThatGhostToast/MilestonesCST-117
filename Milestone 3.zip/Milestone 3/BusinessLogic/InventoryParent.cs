﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    /// <summary>
    /// Zac Almas
    /// CST-117
    /// 12/6/20
    /// This is my code for milestone 3
    public class InventoryParent
    {
        //Define the attributes
        public string gameName { get; private set; }
        public string releaseDate { get; private set; }
        public string graphicsQual { get; private set; }
        public string genre { get; private set; }
        public double campaignLength { get; private set; }
        public double replayability { get; private set; }
        public int quantity { get; set; }
        public int id { get; private set; }

        /// <summary>
        /// Constructor for Inventory Parent
        /// </summary>
        /// <param name="gameName"></param>
        /// <param name="releaseDate"></param>
        /// <param name="graphicsQual"></param>
        /// <param name="genre"></param>
        /// <param name="campaignLength"></param>
        /// <param name="replayability"></param>
        public InventoryParent(string gameNameVal, string releaseDateVal, string graphicsQualVal, string genreVal, double campaignLengthVal, double replayabilityVal, int quantityVal, int idVal)
        {
            this.gameName = gameNameVal;
            this.releaseDate = releaseDateVal;
            this.graphicsQual = graphicsQualVal;
            this.genre = genreVal;
            this.campaignLength = campaignLengthVal;
            this.replayability = replayabilityVal;
            this.quantity = quantityVal;
            this.id = idVal;
        }
    }
}
