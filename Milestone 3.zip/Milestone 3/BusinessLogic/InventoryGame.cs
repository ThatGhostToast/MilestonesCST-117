﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    /// <summary>
    /// Zac Almas
    /// CST-117
    /// 12/6/20
    /// This is my code for milestone 3
    public class InventoryGame : InventoryParent
    {
        public InventoryGame(string gameNameVal, string releaseDateVal, string graphicsQualVal, string genreVal, double campaignLengthVal, double replayabilityVal, int quantityVal, int idVal)
            : base(gameNameVal, releaseDateVal, graphicsQualVal, genreVal, campaignLengthVal, replayabilityVal, quantityVal, idVal)
        {

        }

    }
}
