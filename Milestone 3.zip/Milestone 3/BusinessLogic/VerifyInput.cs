﻿using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Zac Almas
/// CST-117
/// 12/6/20
/// This is my code for milestone 3
namespace BusinessLogic
{
    public class VerifyInput
    {
        //Test the campaign length input
        public double testCampaignLength(string strCampLength)
        {
            //Define a variable to validate the user input
            //If it returns the input number, the input was correct
            //If it returns -1 then the user input a character that created an error
            double campaignLength = -1;

            //Try catch to test input
            try
            {
                //Convert the string to a double
                campaignLength = Convert.ToDouble(strCampLength);
                return campaignLength;
            }
            catch
            {
                return -1;
            }
        }

        //Test the replayability score input
        public double testReplayScore(string strReplayScore)
        {
            //Define a variable to validate the user input
            //If it returns the input number, the input was correct
            //If it returns -1 then the user input a character that created an error
            double replayabilityScore = -1;

            //Try catch to test input
            try
            {
                //Convert the string to a double
                replayabilityScore = Convert.ToDouble(strReplayScore);
                return replayabilityScore;
            }
            catch
            {
                return -1;
            }
        }

        //Test the game ID input
        public int testGameId(string strGameId)
        {
            //Define a variable to validate the user input
            //If it returns the input number, the input was correct
            //If it returns -1 then the user input a character that created an error
            int gameId = -1;

            //Try catch to test input
            try
            {
                //Convert string to an int
                gameId = Convert.ToInt32(strGameId);
                return gameId;
            }
            catch
            {
                return -1;
            }
        }

        //Test the quantity input
        public int testQuantity(string strQuantity)
        {
            //Define a variable to validate the user input
            //If it returns the input number, the input was correct
            //If it returns -1 then the user input a character that created an error
            int quantity = -1;

            //Try catch to test input
            try
            {
                //Convert string to an int
                quantity = Convert.ToInt32(strQuantity);
                return quantity;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// Method that changes the numbered index of the genre selection into a string 
        /// </summary>
        /// <param name="genreNum"></param>
        /// <returns></returns>
        public string setGenreName(int genreNum)
        {
            //Setting a string variable to return the genre name
            string genreName = "";

            //Using the selected index from the list box, the number is changed into a string variable
            //If the index is 0 sets the genre name to fps
            if (genreNum == 0)
            {
                genreName = "FPS";
            }
            //If the index is 1 sets the genre name to RPG
            if (genreNum == 1)
            {
                genreName = "RPG";
            }
            //If the index is 2 sets the genre name to racing
            if (genreNum == 2)
            {
                genreName = "Racing";
            }
            //If the index is 3 sets the genre name to Survival
            if (genreNum == 3)
            {
                genreName = "Survival";
            }
            //If the index is 4 sets the genre name to Fighting
            if (genreNum == 4)
            {
                genreName = "Fighting";
            }
            //If the index is 5 sets the genre name to Puzzle
            if (genreNum == 5)
            {
                genreName = "Puzzle";
            }

            return genreName;

        }

    }
}
