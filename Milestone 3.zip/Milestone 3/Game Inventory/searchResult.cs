﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// Zac Almas
/// CST-117
/// 12/6/20
/// This is my code for milestone 3
namespace Game_Inventory
{
    public partial class searchResult : Form
    {
        List<InventoryGame> resultSearch = new List<InventoryGame>();
        DataTable dt = new DataTable();
        public searchResult(List<InventoryGame> searchResults)
        {
            InitializeComponent();
            resultSearch = searchResults;

            //======================
            //Update the data table
            //======================
            dgSearchResult.ColumnCount = 8;
            dgSearchResult.Columns[0].Name = "ID";
            dgSearchResult.Columns[1].Name = "Game Name";
            dgSearchResult.Columns[2].Name = "Release Date";
            dgSearchResult.Columns[3].Name = "Graphics Quality";
            dgSearchResult.Columns[4].Name = "Game Genre";
            dgSearchResult.Columns[5].Name = "Campaign Length";
            dgSearchResult.Columns[6].Name = "Replayability Score";
            dgSearchResult.Columns[7].Name = "Quantity";

            //Clear the table
            dgSearchResult.Rows.Clear();

            //===================
            //Populate the table
            //===================

            foreach (var game in resultSearch)
            {
                dgSearchResult.Rows.Add(game.id, game.gameName, game.releaseDate, game.graphicsQual, game.genre, game.campaignLength, game.replayability, game.quantity);
            }

        }

    }
}
