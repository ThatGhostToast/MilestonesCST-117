﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic;

/// <summary>
/// Zac Almas
/// CST-117
/// 12/6/20
/// This is my own code used for milestone 3
/// </summary>
namespace Game_Inventory
{
    public partial class gameInventory : Form
    {
        //Create the inventory reference variable
        List<InventoryGame> myInventory = new List<InventoryGame>();
        List<InventoryGame> searchResultList = new List<InventoryGame>();

        //Create an instance of the data table
        DataTable dt = new DataTable();
        public gameInventory()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Clicking this button adds in a game to our inventory
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddGame_Click(object sender, EventArgs e)
        {
            //Define Variables
            string genreName = "";
            double campaignLength = 0;
            double replayScore = 0;
            int id = -1;
            int genreNum = lbGameGenre.SelectedIndex;
            int quantity = 0;

            //====================
            //Verify number input
            //====================
            VerifyInput testInputData = new VerifyInput();
            campaignLength = testInputData.testCampaignLength(txtCampLength.Text);
            replayScore = testInputData.testReplayScore(txtReplayability.Text);
            id = testInputData.testGameId(txtGameId.Text);
            quantity = testInputData.testQuantity(txtQuantity.Text);

            VerifyInput setGenreName = new VerifyInput();
            genreName = setGenreName.setGenreName(genreNum);

            if (campaignLength == -1)
            {
                showMessage("Campaign Length input can only be numbers. Please enter a number.");
                txtCampLength.Focus();
                txtCampLength.SelectAll();
            }else if(replayScore == -1)
            {
                showMessage("Replayability Score input can only be numbers. Please enter a number.");
                txtReplayability.Focus();
                txtReplayability.SelectAll();
            }else if (id == -1)
            {
                showMessage("Game ID input can only be numbers. Please enter a number.");
                txtGameId.Focus();
                txtGameId.SelectAll();
            }else if(quantity == -1)
            {
                showMessage("The quantity input can only be numbers. Please enter a number.");
                txtQuantity.Focus();
                txtQuantity.SelectAll();
            }else if (lbGameGenre.SelectedIndex == -1)
            {
                showMessage("Please select a game genre.");
            }
            else
            {
                //========================
                //Add Game into Inventory
                //========================
                InventoryManager newGame = new InventoryManager(txtGameName.Text, txtReleaseDate.Text, txtGraphicsQual.Text, genreName, campaignLength, replayScore, quantity, id, myInventory);
                myInventory = newGame.addToInventory();

                ClearInputBoxes();

                //======================
                //Update the data table
                //======================
                dgGameInventory.ColumnCount = 8;
                dgGameInventory.Columns[0].Name = "ID";
                dgGameInventory.Columns[1].Name = "Game Name";
                dgGameInventory.Columns[2].Name = "Release Date";
                dgGameInventory.Columns[3].Name = "Graphics Quality";
                dgGameInventory.Columns[4].Name = "Game Genre";
                dgGameInventory.Columns[5].Name = "Campaign Length";
                dgGameInventory.Columns[6].Name = "Replayability Score";
                dgGameInventory.Columns[7].Name = "Quantity";

                //Clear the table
                dgGameInventory.Rows.Clear();

                //===================
                //Populate the table
                //===================
                foreach (var game in myInventory)
                {
                    dgGameInventory.Rows.Add(game.id, game.gameName, game.releaseDate, game.graphicsQual, game.genre, game.campaignLength, game.replayability, game.quantity);
                }


            }


        }

        /// <summary>
        /// This button can be used to delete a game in the inventory
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Define variables
            int idToBeDeleted = -1;

            //Temp Variables
            //Temp variables allow us to grab the method in the inventoryManager class when we dont have the variables required
            //In this instance we did not need most of the input but without them we could not get the method out of the class
            double campLength = 0;
            double replay = 0;
            int quantity = 0;
            string genre = "";

            //====================
            //Verify number input
            //====================
            VerifyInput testInputData = new VerifyInput();
            idToBeDeleted = testInputData.testGameId(txtDeleteId.Text);
            if(idToBeDeleted == -1)
            {
                showMessage("Game ID input can only be numbers. Please enter a number.");
            }
            else
            {
                InventoryManager deleteGame = new InventoryManager(txtGameName.Text, txtReleaseDate.Text, txtGraphicsQual.Text, genre, campLength, replay, quantity, idToBeDeleted, myInventory);
                myInventory = deleteGame.deleteFromInventory(idToBeDeleted);

                //======================
                //Update the data table
                //======================
                dgGameInventory.ColumnCount = 8;
                dgGameInventory.Columns[0].Name = "ID";
                dgGameInventory.Columns[1].Name = "Game Name";
                dgGameInventory.Columns[2].Name = "Release Date";
                dgGameInventory.Columns[3].Name = "Graphics Quality";
                dgGameInventory.Columns[4].Name = "Game Genre";
                dgGameInventory.Columns[5].Name = "Campaign Length";
                dgGameInventory.Columns[6].Name = "Replayability Score";
                dgGameInventory.Columns[7].Name = "Quantity";

                //Clear the table
                dgGameInventory.Rows.Clear();

                //===================
                //Populate the table
                //===================
                foreach (var game in myInventory)
                {
                    dgGameInventory.Rows.Add(game.id, game.gameName, game.releaseDate, game.graphicsQual, game.genre, game.campaignLength, game.replayability, game.quantity);
                }
            }

        }

        /// <summary>
        /// This button allows the user to update the quantity of the game in the inventory
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Define variables
            int idToBeUpdated = -1;
            int newQuantity = -1;

            //Temp Variables
            //Temp variables allow us to grab the method in the inventoryManager class when we dont have the variables required
            //In this instance we did not need most of the input but without them we could not get the method out of the class
            double campLength = 0;
            double replay = 0;
            int quantity = 0;
            string genre = "";

            //====================
            //Verify number input
            //====================
            VerifyInput testInputData = new VerifyInput();
            idToBeUpdated = testInputData.testGameId(txtUpdateID.Text);
            newQuantity = testInputData.testQuantity(txtNewQuantity.Text);
            if (idToBeUpdated == -1)
            {
                showMessage("Game ID input can only be numbers. Please enter a number.");
            }
            else if (newQuantity == -1)
            {
                showMessage("The quantity input needs to be a number. Please enter a number.");
            }
            else
            {
                InventoryManager updateQuantity = new InventoryManager(txtGameName.Text, txtReleaseDate.Text, txtGraphicsQual.Text, genre, campLength, replay, quantity, idToBeUpdated, myInventory);
                myInventory = updateQuantity.restockGame(newQuantity, idToBeUpdated);

                //======================
                //Update the data table
                //======================
                dgGameInventory.ColumnCount = 8;
                dgGameInventory.Columns[0].Name = "ID";
                dgGameInventory.Columns[1].Name = "Game Name";
                dgGameInventory.Columns[2].Name = "Release Date";
                dgGameInventory.Columns[3].Name = "Graphics Quality";
                dgGameInventory.Columns[4].Name = "Game Genre";
                dgGameInventory.Columns[5].Name = "Campaign Length";
                dgGameInventory.Columns[6].Name = "Replayability Score";
                dgGameInventory.Columns[7].Name = "Quantity";

                //Clear the table
                dgGameInventory.Rows.Clear();

                //===================
                //Populate the table
                //===================
                foreach (var game in myInventory)
                {
                    dgGameInventory.Rows.Add(game.id, game.gameName, game.releaseDate, game.graphicsQual, game.genre, game.campaignLength, game.replayability, game.quantity);
                }
            }

        }

        /// <summary>
        /// Clicking this button will take in search criteria and search the inventory for it
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            int idToBeSearched = -1;

            //Temp Variables
            //Temp variables allow us to grab the method in the inventoryManager class when we dont have the variables required
            //In this instance we did not need most of the input but without them we could not get the method out of the class
            double campLength = 0;
            double replay = 0;
            int quantity = 0;
            string genre = "";

            //====================
            //Verify number input
            //====================
            VerifyInput testInputData = new VerifyInput();
            idToBeSearched = testInputData.testGameId(txtSearchID.Text);
            if (idToBeSearched == -1)
            {
                showMessage("Please enter a valid number.");
                txtSearchID.Focus();
                txtSearchID.SelectAll();
            }
            else if (String.IsNullOrEmpty(txtSearchName.Text))
            {
                showMessage("Please enter a name to be searched.");
                txtSearchName.Focus();
                txtSearchName.SelectAll();
            }
            else
            {
                //Sending the variables to the manager that will return the search results
                InventoryManager searchInventory = new InventoryManager(txtSearchName.Text, txtReleaseDate.Text, txtGraphicsQual.Text, genre, campLength, replay, quantity, idToBeSearched, myInventory);
                searchResultList = searchInventory.searchInv(idToBeSearched, txtSearchName.Text);

                //Sending the search results to a new tab to be displayed
                searchResult inv = new searchResult(myInventory);

                //Displaying the search results
                inv.Show();

            }
        }

        /// <summary>
        /// This shows a message if there is an error
        /// </summary>
        /// <param name="messageToShow"></param>
        public void showMessage(string messageToShow)
        {
            MessageBox.Show(messageToShow);
        }
        
        /// <summary>
        /// This clears the input boxes
        /// </summary>
        private void ClearInputBoxes()
        {
            txtCampLength.Text = "";
            txtGameName.Text = "";
            txtGraphicsQual.Text = "";
            txtReleaseDate.Text = "";
            txtReplayability.Text = "";
            txtGameId.Text = "";
            txtDeleteId.Text = "";
            txtQuantity.Text = "";
            txtUpdateID.Text = "";
            txtNewQuantity.Text = "";
            lbGameGenre.ClearSelected();
        }

    }
}
